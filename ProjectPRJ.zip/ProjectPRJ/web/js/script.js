// script.js (đã sửa)
document.addEventListener('DOMContentLoaded', function() {
    // Xử lý input quantity
    const quantityInputs = document.querySelectorAll('.quantity-input');
    
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.value < 1) {
                this.value = 1;
            }
        });
    });

    // Hiệu ứng và xử lý cho nút "Thêm vào Giỏ" (.add-to-cart-btn)
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    addToCartButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); // Ngăn chặn hành vi mặc định
            const form = this.closest('form'); // Tìm form cha gần nhất

            if (form) { // Kiểm tra xem form có tồn tại không
                // Thêm hiệu ứng thay đổi màu
                this.style.backgroundColor = '#0056b3';
                setTimeout(() => {
                    this.style.backgroundColor = '#007bff';
                    form.submit(); // Gửi form nếu tồn tại
                }, 200);
            } else {
                console.error('Form not found for button: .add-to-cart-btn');
                // Nếu không tìm thấy form, gửi yêu cầu trực tiếp (nếu là liên kết)
                const href = this.getAttribute('href');
                if (href) {
                    window.location.href = href; // Chuyển hướng nếu là liên kết
                } else {
                    alert('Không thể gửi form. Vui lòng kiểm tra cấu trúc HTML.');
                }
            }
        });
    });

    // Hiệu ứng và xử lý cho nút "Cập nhật" và "Xóa" (.btn-primary, .btn-danger)
    const actionButtons = document.querySelectorAll('.btn-primary, .btn-danger');
    actionButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); // Ngăn chặn hành vi mặc định
            const form = this.closest('form'); // Tìm form cha gần nhất

            if (form) { // Kiểm tra xem form có tồn tại không
                // Thêm hiệu ứng thay đổi kích thước
                this.style.transform = 'scale(1.1)';
                setTimeout(() => {
                    this.style.transform = 'scale(1)';
                    form.submit(); // Gửi form nếu tồn tại
                }, 200);
            } else {
                console.error('Form not found for button: .btn-primary or .btn-danger');
                // Nếu không tìm thấy form, gửi yêu cầu trực tiếp (nếu là liên kết)
                const href = this.getAttribute('href');
                if (href) {
                    window.location.href = href; // Chuyển hướng nếu là liên kết
                } else {
                    alert('Không thể gửi form. Vui lòng kiểm tra cấu trúc HTML.');
                }
            }
        });
    });

    // Xử lý riêng cho nút "Đăng Xuất" (nếu cần)
    const logoutButtons = document.querySelectorAll('.logout-btn');
    logoutButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); // Ngăn chặn hành vi mặc định nếu cần
            const href = this.getAttribute('href');
            if (href) {
                window.location.href = href; // Chuyển hướng trực tiếp đến /logout
            } else {
                console.error('Logout link not found');
                alert('Không thể đăng xuất. Vui lòng kiểm tra liên kết.');
            }
        });
    });
});