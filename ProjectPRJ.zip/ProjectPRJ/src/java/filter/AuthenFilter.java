package filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import model.User;

/**
 *
 * @author ACER
 */
@WebFilter(filterName = "Filter", urlPatterns = {"/*"})
public class AuthenFilter implements jakarta.servlet.Filter {
    private static final boolean debug = true;

    private FilterConfig filterConfig = null;

    public AuthenFilter() {
    }

    private static final String LOGIN_PAGE = "/login.jsp";

    private static final List<String> PUBLIC_RESOURCES = Arrays.asList("/login.jsp", "/login", "/logout", ".css", ".png", ".js");
    private static final List<String> ADMIN_PAGES = Arrays.asList("/admin.jsp", "/manageUsers", "/products", "/products?action=create", "/products?action=edit", "/products?action=delete");
    private static final List<String> USER_PAGES = Arrays.asList("/carts", "/checkout", "/productListCart.jsp", "/cart.jsp", "/success.jsp", "/products");

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();
        String path = uri.substring(contextPath.length()); // Lấy phần đường dẫn sau context path

        // Kiểm tra nếu response đã bị commit, không thực hiện thêm gì
        if (res.isCommitted()) {
            chain.doFilter(request, response);
            return;
        }

        // Bỏ qua kiểm tra nếu tài nguyên là công khai
        for (String resource : PUBLIC_RESOURCES) {
            if (path.endsWith(resource) || path.contains(resource)) {
                chain.doFilter(request, response);
                return;
            }
        }

        // Kiểm tra session và lấy user đăng nhập
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null; // Sử dụng "UserLogin" cho nhất quán

        if (user == null) {
            // Nếu chưa đăng nhập, chuyển hướng đến trang login.jsp với thông báo lỗi
            req.setAttribute("errorMessage", "Bạn cần đăng nhập để truy cập trang này!");
            res.sendRedirect(contextPath + LOGIN_PAGE + "?error=unauthorized");
            return;
        }

        // Lấy tài nguyên mà user đang truy cập (bỏ qua tham số query nếu có)
        String resource = path;
        if (resource.contains("?")) {
            resource = resource.substring(0, resource.indexOf("?"));
        }

        String role = user.getRole();

        // Debug: Log thông tin
        System.out.println("AuthenFilter - URI: " + uri + ", User: " + user + ", Role: " + (user != null ? user.getRole() : "null"));

        // Chặn nếu không phải admin mà thực hiện create/edit/delete
        String action = req.getParameter("action");
        if (!"admin".equals(role) && action != null && 
            (action.equals("create") || action.equals("edit") || action.equals("delete"))) {
            req.setAttribute("errorMessage", "Bạn cần quyền admin để thực hiện hành động này!");
            res.sendRedirect(contextPath + LOGIN_PAGE);
            return;
        }

        // Kiểm tra quyền truy cập trang
        boolean isAuthorized = false;
        if ("admin".equals(role)) {
            for (String adminPage : ADMIN_PAGES) {
                if (resource.startsWith(adminPage) || resource.equals(adminPage)) {
                    isAuthorized = true;
                    break;
                }
            }
        } else if ("user".equals(role)) {
            for (String userPage : USER_PAGES) {
                if (resource.startsWith(userPage) || resource.equals(userPage)) {
                    isAuthorized = true;
                    break;
                }
            }
        }

        if (isAuthorized) {
            session.setAttribute("isAdmin", "admin".equals(role));
            chain.doFilter(request, response);
        } else {
            req.setAttribute("errorMessage", "Bạn không có quyền truy cập trang này!");
            res.sendRedirect(contextPath + LOGIN_PAGE);
        }
    }

    @Override
    public void destroy() {
    }

    @Override
    public void init(FilterConfig filterConfig) {
        this.filterConfig = filterConfig;
        if (filterConfig != null && debug) {
            // log("NewFilter:Initializing filter");
        }
    }
}