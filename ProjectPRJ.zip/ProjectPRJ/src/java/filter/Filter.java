/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import model.User;

/**
 *
 * @author ACER
 */
@WebFilter(filterName = "Filter", urlPatterns = {"/*"})
public class Filter implements jakarta.servlet.Filter {
        private static final boolean debug = true;

    // The filter configuration object we are associated with.  If
    // this value is null, this filter instance is not currently
    // configured. 
    private FilterConfig filterConfig = null;
    
    public Filter() {
    }    
    
    private static final String LOGIN_PAGE = "login.jsp";

    private static final List<String> ADMIN_PAGES = Arrays.asList("admin.jsp", "manageUsers", "products");//,
    private static final List<String> USER_PAGES = Arrays.asList("products","carts","checkout","productListCart.jsp","cart.jsp","success.jsp");
    private static final List<String> PUBLIC_RESOURCES = Arrays.asList("login.jsp", "login",".css", ".png");

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            HttpServletRequest req = (HttpServletRequest) request;
            HttpServletResponse res = (HttpServletResponse) response;
            String uri = req.getRequestURI();
            String action = req.getParameter("action");

            // Bỏ qua kiểm tra nếu tài nguyên là công khai
            for (String resource : PUBLIC_RESOURCES) {
                if (uri.contains(resource)) {
                    chain.doFilter(request, response);
                    return;
                }
            }

            // Kiểm tra session và lấy user đăng nhập
            HttpSession session = req.getSession(false);
            User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

            if (user == null) {
                res.sendRedirect(LOGIN_PAGE);
                return;
            }

            // Lấy tài nguyên mà user đang truy cập
            String resource = uri.substring(uri.lastIndexOf("/") + 1);
            String role = user.getRole();

            // Chặn nếu không phải admin mà truy cập create/edit/delete
            if (!"admin".equals(role) && action != null &&
                (action.equals("create") ||action.equals("edit") || action.equals("delete"))) {
                res.sendRedirect(LOGIN_PAGE);
                return;
            }
            
            
            // Kiểm tra quyền truy cập trang
            boolean isAuthorized = false;
            if ("admin".equals(role)) {
                isAuthorized = ADMIN_PAGES.contains(resource);
            } else if ("user".equals(role)) {
                isAuthorized = USER_PAGES.contains(resource);
            }
            
            // Nếu truy cập /logout  hủy session
            if ("logout".equals(resource)) {             
                session.invalidate(); 
                res.sendRedirect(LOGIN_PAGE); 
                return; 
            }

            if (isAuthorized) {
                session.setAttribute("isAdmin", "admin".equals(role));
                chain.doFilter(request, response);
                
            } else {
                res.sendRedirect(LOGIN_PAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            ((HttpServletResponse) response).sendRedirect(LOGIN_PAGE);
        }
    }
        @Override
        public void destroy() {        
    }

    /**
     * Init method for this filter
     */
        @Override
    public void init(FilterConfig filterConfig) {        
        this.filterConfig = filterConfig;
        if (filterConfig != null) {
            if (debug) {                
                //log("NewFilter:Initializing filter");
            }
        }
    }
}
    
     