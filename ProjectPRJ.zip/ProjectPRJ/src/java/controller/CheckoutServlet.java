/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Cart;
import model.CartItem;
import model.Order;
import orderDao.OrderDao;
import productDao.ProductDao;

/**
 *
 * @author ACER
 */


@WebServlet(name = "CheckoutServlet", urlPatterns = {"/checkout"})
public class CheckoutServlet extends HttpServlet {
    private OrderDao orderDAO = new OrderDao();
    private ProductDao productDao = new ProductDao();



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart"); // Lấy giỏ hàng đúng kiểu

        if (cart == null || cart.getItems().isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        int userId = 1; // Giả sử người dùng đã đăng nhập
        double totalPrice = 0.0;

        // Tính tổng tiền đơn hàng
        for (CartItem item : cart.getItems()) {
            totalPrice += item.getProduct().getPrice() * item.getQuantity();
        }

        // Tạo đơn hàng mới
        Order order = new Order(0, userId, totalPrice, "Pending");
        int orderId = 0;
        try {
            orderId = orderDAO.createOrderReturnId(order);
        } catch (SQLException ex) {
            Logger.getLogger(CheckoutServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Thêm chi tiết đơn hàng
        for (CartItem item : cart.getItems()) {
            orderDAO.addOrderDetail(orderId, item.getProduct().getId(), item.getQuantity(), item.getProduct().getPrice());
        }

        // Xóa giỏ hàng sau khi đặt hàng thành công
        session.removeAttribute("cart");
        response.sendRedirect("success.jsp");
    }
}
