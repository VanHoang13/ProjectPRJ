/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author ACER
 */
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import model.User;
import userDao.UserDao;
@WebServlet(name = "UserServlet", urlPatterns = "/manageUsers")
public class UserServlet extends HttpServlet {
    private UserDao userDAO;

    public void init() {
        userDAO = new UserDao();
    }

    @Override
    protected void doPost(HttpServletRequest request,HttpServletResponse response)
        throws ServletException, IOException {
    String action = request.getParameter("action");
    if (action == null) {
        action = "";
    }
    try {
        switch (action) {
        case "create":
        insertUser(request, response);
        break;
        case "edit":
        updateUser(request, response);
        break;
       
        }
    } catch (SQLException ex) {
        throw new ServletException(ex);
    }
    }
    @Override
    protected void doGet(HttpServletRequest request,HttpServletResponse response)
        throws ServletException, IOException {
    String action = request.getParameter("action");
    if (action == null) {
        action = "";
    }
    try {
    switch (action) {
        case "create":
        showNewForm(request, response);
        break;
        case "edit":
        showEditForm(request, response);
        break;
        case "delete":
        deleteUser(request, response);
        break;
        default:
        listUser(request, response);
        break;
        }
    } catch (SQLException ex) {
    throw new ServletException(ex);
    }
    }

    private void listUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<User> listUser = userDAO.selectAllUsers();
        request.setAttribute("listUser", listUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("user/listUser.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       RequestDispatcher dispatcher = request.getRequestDispatcher("user/createUser.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        User existingUser = userDAO.selectUser(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("user/editUser.jsp");
        request.setAttribute("user", existingUser);
        dispatcher.forward(request, response);
    }

//    private void insertUser(HttpServletRequest request, HttpServletResponse response)
//            throws SQLException, IOException {
//        User user = new User(
//                0,
//                request.getParameter("username"),
//                request.getParameter("password"),
//                request.getParameter("role")
//
//        );
//        userDAO.insertUser(user);
//        response.sendRedirect("manageUsers?action=list");
//    }
    private void insertUser(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {
    
    String username = request.getParameter("username");
    String password = request.getParameter("password");
    String role = request.getParameter("role");
    User newUser = new User(0, username,password, role);
    userDAO.insertUser(newUser);

    RequestDispatcher dispatcher = request.getRequestDispatcher("user/createUser.jsp");
    dispatcher.forward(request, response);
}
    
    private void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        User user = new User(
                id,
                request.getParameter("username"),
                request.getParameter("password"),
                request.getParameter("role")
        );
        userDAO.updateUser(user);
        response.sendRedirect("manageUsers?action=list");
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        userDAO.deleteUser(id);
        response.sendRedirect("manageUsers?action=list");
    }
}
