package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import model.Product;
import model.User;
import productDao.ProductDao;

/**
 * Servlet xử lý các thao tác liên quan đến sản phẩm.
 */
@WebServlet(name = "ProductServlet", urlPatterns = "/products")
public class ProductServlet extends HttpServlet {
    private ProductDao productDAO;

    @Override
    public void init() {
        productDAO = new ProductDao(); // Khởi tạo ProductDao
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;
        String role = (user != null) ? user.getRole() : "";

        // Debug: Log thông tin
        System.out.println("ProductServlet doGet - User: " + user + ", Role: " + role + ", Action: " + request.getParameter("action"));

        String action = request.getParameter("action");
        if (action == null || action.isEmpty()) {
            action = "list"; // Mặc định là danh sách sản phẩm
        }

        try {
            switch (action) {
                case "create":
                    showNewForm(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteProduct(request, response);
                    break;
                default:
                    listProducts(request, response, role);
                    break;
            }
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Lỗi khi truy vấn cơ sở dữ liệu: " + ex.getMessage());
            response.sendRedirect("products");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null || action.isEmpty()) {
            response.sendRedirect("products");
            return;
        }

        try {
            switch (action) {
                case "create":
                    insertProduct(request, response);
                    break;
                case "edit":
                    updateProduct(request, response);
                    break;
                default:
                    response.sendRedirect("products");
                    break;
            }
        } catch (SQLException ex) {
            request.setAttribute("errorMessage", "Lỗi khi xử lý yêu cầu: " + ex.getMessage());
            response.sendRedirect("products");
        } catch (NumberFormatException ex) {
            request.setAttribute("errorMessage", "Dữ liệu không hợp lệ: " + ex.getMessage());
            response.sendRedirect("products");
        }
    }

    private void listProducts(HttpServletRequest request, HttpServletResponse response, String role) 
            throws ServletException, IOException, SQLException {
        // Lấy danh sách sản phẩm
        List<Product> listProducts = productDAO.selectAllProducts();
        
        // Debug: Kiểm tra số lượng sản phẩm
        System.out.println("Số lượng sản phẩm: " + (listProducts != null ? listProducts.size() : "null"));

        if (listProducts == null || listProducts.isEmpty()) {
            request.setAttribute("errorMessage", "Không có sản phẩm nào trong cơ sở dữ liệu!");
        }
        
        request.setAttribute("listProducts", listProducts);

        // Xác định trang JSP dựa trên vai trò
        String page;
        if ("admin".equals(role)) {
            page = "product/listProduct.jsp"; // Trang quản lý sản phẩm cho admin
        } else if ("user".equals(role)) {
            page = "product/productListCart.jsp"; // Trang bán hàng cho user
        } else {
            response.sendRedirect("login.jsp"); // Chuyển hướng về trang đăng nhập nếu không có quyền
            return;
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher(page);
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user != null && "admin".equals(user.getRole())) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("product/createProduct.jsp");
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("login.jsp"); // Chỉ admin có quyền thêm sản phẩm
        }
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user != null && "admin".equals(user.getRole())) {
            int id;
            try {
                id = Integer.parseInt(request.getParameter("id"));
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "ID sản phẩm không hợp lệ!");
                response.sendRedirect("products");
                return;
            }

            Product existingProduct = productDAO.selectProduct(id);
            if (existingProduct == null) {
                request.setAttribute("errorMessage", "Sản phẩm không tồn tại!");
                response.sendRedirect("products");
                return;
            }

            RequestDispatcher dispatcher = request.getRequestDispatcher("product/editProduct.jsp");
            request.setAttribute("product", existingProduct);
            dispatcher.forward(request, response);
        } else {
            response.sendRedirect("login.jsp"); // Chỉ admin có quyền sửa sản phẩm
        }
    }

    private void insertProduct(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user != null && "admin".equals(user.getRole())) {
            try {
                String name = request.getParameter("name");
                double price = Double.parseDouble(request.getParameter("price"));
                String description = request.getParameter("description");
                int stock = Integer.parseInt(request.getParameter("stock"));
                String image = request.getParameter("image"); // Thêm field image

                if (name == null || name.trim().isEmpty() || price < 0 || stock < 0) {
                    request.setAttribute("errorMessage", "Dữ liệu không hợp lệ!");
                    response.sendRedirect("products?action=create");
                    return;
                }

                // Giả định image là đường dẫn hoặc tên file mặc định nếu không có
                if (image == null || image.trim().isEmpty()) {
                    image = "default.jpg"; // Đường dẫn mặc định
                }

                Product newProduct = new Product(0, name, price, description, stock, null, image);
                productDAO.insertProduct(newProduct);
                request.setAttribute("successMessage", "Thêm sản phẩm thành công!");
                response.sendRedirect("products");
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "Dữ liệu không đúng định dạng: " + e.getMessage());
                response.sendRedirect("products?action=create");
            }
        } else {
            response.sendRedirect("login.jsp");
        }
    }

    private void updateProduct(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user != null && "admin".equals(user.getRole())) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                String name = request.getParameter("name");
                double price = Double.parseDouble(request.getParameter("price"));
                String description = request.getParameter("description");
                int stock = Integer.parseInt(request.getParameter("stock"));
                String image = request.getParameter("image"); // Thêm field image

                if (name == null || name.trim().isEmpty() || price < 0 || stock < 0) {
                    request.setAttribute("errorMessage", "Dữ liệu không hợp lệ!");
                    response.sendRedirect("products?action=edit&id=" + id);
                    return;
                }

                // Giả định image là đường dẫn hoặc tên file mặc định nếu không có
                if (image == null || image.trim().isEmpty()) {
                    image = "default.jpg"; // Đường dẫn mặc định
                }

                Product updatedProduct = new Product(id, name, price, description, stock, null, image);
                productDAO.updateProduct(updatedProduct);
                request.setAttribute("successMessage", "Cập nhật sản phẩm thành công!");
                response.sendRedirect("products");
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "Dữ liệu không đúng định dạng: " + e.getMessage());
                response.sendRedirect("products");
            }
        } else {
            response.sendRedirect("login.jsp");
        }
    }

    private void deleteProduct(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user != null && "admin".equals(user.getRole())) {
            int id;
            try {
                id = Integer.parseInt(request.getParameter("id"));
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "ID sản phẩm không hợp lệ!");
                response.sendRedirect("products");
                return;
            }

            productDAO.deleteProduct(id);
            request.setAttribute("successMessage", "Xóa sản phẩm thành công!");
            response.sendRedirect("products");
        } else {
            response.sendRedirect("login.jsp");
        }
    }
}