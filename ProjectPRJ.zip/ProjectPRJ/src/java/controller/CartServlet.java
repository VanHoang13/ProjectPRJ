package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import model.Cart;
import model.Product;
import model.User;
import productDao.ProductDao;

@WebServlet(name = "CartServlet", urlPatterns = "/carts")
public class CartServlet extends HttpServlet {
    private ProductDao productDAO;

    @Override
    public void init() {
        productDAO = new ProductDao(); // Khởi tạo ProductDao
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user == null) {
            request.setAttribute("errorMessage", "Bạn cần đăng nhập để truy cập giỏ hàng!");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        System.out.println("CartServlet doGet - User: " + user + ", Role: " + user.getRole() + ", Cart size: " + (cart.getItems() != null ? cart.getItems().size() : 0));

        request.setAttribute("cart", cart);
        request.getRequestDispatcher("/cart.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        if (user == null) {
            request.setAttribute("errorMessage", "Bạn cần đăng nhập để thực hiện hành động này!");
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        String action = request.getParameter("action");
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        System.out.println("CartServlet doPost - Action: " + action + ", User: " + user + ", Role: " + user.getRole());

        try {
            switch (action) {
                case "add":
                    String productIdStr = request.getParameter("productId");
                    int productId;
                    try {
                        productId = Integer.parseInt(productIdStr);
                        if (productId <= 0) {
                            request.setAttribute("errorMessage", "ID sản phẩm không hợp lệ: " + productIdStr);
                            response.sendRedirect(request.getContextPath() + "/products");
                            return;
                        }
                    } catch (NumberFormatException e) {
                        request.setAttribute("errorMessage", "ID sản phẩm không hợp lệ: " + productIdStr + " - " + e.getMessage());
                        response.sendRedirect(request.getContextPath() + "/products");
                        return;
                    }

                    int quantity;
                    try {
                        quantity = Integer.parseInt(request.getParameter("quantity"));
                        if (quantity < 1) {
                            request.setAttribute("errorMessage", "Số lượng phải lớn hơn 0!");
                            response.sendRedirect(request.getContextPath() + "/products");
                            return;
                        }
                    } catch (NumberFormatException e) {
                        request.setAttribute("errorMessage", "Số lượng không hợp lệ: " + e.getMessage());
                        response.sendRedirect(request.getContextPath() + "/products");
                        return;
                    }

                    // Lấy thông tin sản phẩm từ ProductDao
                    Product product = productDAO.selectProduct(productId);
                    if (product == null) {
                        request.setAttribute("errorMessage", "Sản phẩm không tồn tại với ID: " + productId);
                        response.sendRedirect(request.getContextPath() + "/products");
                        return;
                    }

                    // Thêm sản phẩm vào giỏ hàng
                    cart.addItem(product, quantity);
                    System.out.println("Added product to cart - Product ID: " + productId + ", Quantity: " + quantity + ", Cart size: " + cart.getItems().size());

                    // Xử lý redirectTo
                    String redirectTo = request.getParameter("redirectTo");
                    if (redirectTo != null && !redirectTo.trim().isEmpty()) {
                        response.sendRedirect(redirectTo);
                    } else {
                        request.setAttribute("successMessage", "Thêm sản phẩm vào giỏ hàng thành công!");
                        response.sendRedirect(request.getContextPath() + "/products");
                    }
                    break;
                case "update":
                    int updateProductId = Integer.parseInt(request.getParameter("productId"));
                    int updateQuantity = Integer.parseInt(request.getParameter("quantity"));
                    cart.updateItem(updateProductId, updateQuantity);
                    request.setAttribute("successMessage", "Cập nhật số lượng thành công!");
                    response.sendRedirect(request.getContextPath() + "/carts");
                    break;
                case "remove":
                    int removeProductId = Integer.parseInt(request.getParameter("productId"));
                    cart.removeItem(removeProductId);
                    request.setAttribute("successMessage", "Xóa sản phẩm thành công!");
                    response.sendRedirect(request.getContextPath() + "/carts");
                    break;
                default:
                    response.sendRedirect(request.getContextPath() + "/carts");
            }
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Lỗi khi xử lý yêu cầu: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/products");
            System.out.println("Exception in CartServlet: " + e.getMessage());
        }
    }
}