package controller;

/**
 *
 * @author ACER
 */

import model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import userDao.UserDao;

@WebServlet(name="LoginServlet", urlPatterns={"/login"})
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        UserDao userDao = new UserDao();
        User user = userDao.getUserByUsernameAndPassword(username, password);

        if (user != null) {
            HttpSession session = request.getSession(true); // Tạo session mới
            session.setAttribute("UserLogin", user);
            session.setMaxInactiveInterval(30 * 60); // Đặt timeout là 30 phút

            // Debug: Log thông tin đăng nhập
            System.out.println("LoginServlet - User logged in: " + user.getUsername() + ", Role: " + user.getRole());

            if ("user".equals(user.getRole())) {
                response.sendRedirect("products"); // Chuyển hướng đến trang products (xử lý bởi ProductServlet)
            } else if ("admin".equals(user.getRole())) {
                response.sendRedirect("admin.jsp");
            } else {
                request.setAttribute("errorMessage", "Vai trò người dùng không hợp lệ!");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("errorMessage", "Sai tên đăng nhập hoặc mật khẩu!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
}