package productDao;

import java.sql.SQLException;
import model.Product;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import dao.DBConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ACER
 */
public class ProductDao implements IProductDAO {
    private static final String INSERT_PRODUCT = "INSERT INTO Product (name, price, description, stock, image) VALUES (?, ?, ?, ?, ?)";
    private static final String SELECT_PRODUCT_BY_ID = "SELECT * FROM Product WHERE id = ?";
    private static final String SELECT_ALL_PRODUCTS = "SELECT * FROM Product";
    private static final String UPDATE_PRODUCT = "UPDATE Product SET name = ?, price = ?, description = ?, stock = ?, image = ? WHERE id = ?";
    private static final String DELETE_PRODUCT = "DELETE FROM Product WHERE id = ?";

    @Override
    public void insertProduct(Product product) throws SQLException {
        try (java.sql.Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(INSERT_PRODUCT);
                ps.setString(1, product.getName());
                ps.setDouble(2, product.getPrice());
                ps.setString(3, product.getDescription());
                ps.setInt(4, product.getStock());
                ps.setString(5, product.getImage()); // Thêm image
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public Product selectProduct(int id) {
        try (java.sql.Connection conn = DBConnection.getConnection()) {
            if (conn != null) {
                PreparedStatement ps = conn.prepareStatement(SELECT_PRODUCT_BY_ID);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    return new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getString("description"),
                        rs.getInt("stock"),
                        rs.getTimestamp("import_date"),
                        rs.getString("image") // Thêm image
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Product> selectAllProducts() {
        try {
            List<Product> products = new ArrayList<>();
            java.sql.Connection conn = DBConnection.getConnection();
            
            if (conn == null) {
                System.err.println("Database connection failed in selectAllProducts().");
                return products;
            }
            
            try (PreparedStatement ps = conn.prepareStatement(SELECT_ALL_PRODUCTS);
                    ResultSet rs = ps.executeQuery()) {
                
                while (rs.next()) {
                    products.add(new Product(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDouble("price"),
                            rs.getString("description"),
                            rs.getInt("stock"),
                            rs.getTimestamp("import_date"),
                            rs.getString("image") // Thêm image
                    ));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return products;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public boolean updateProduct(Product product) {
        boolean rowUpdated = false;
        try (java.sql.Connection conn = DBConnection.getConnection()) {
            if (conn != null) { 
                PreparedStatement ps = conn.prepareStatement(UPDATE_PRODUCT);
                ps.setString(1, product.getName());
                ps.setDouble(2, product.getPrice());
                ps.setString(3, product.getDescription());
                ps.setInt(4, product.getStock());
                ps.setString(5, product.getImage()); // Thêm image
                ps.setInt(6, product.getId());
                rowUpdated = ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }

    @Override
    public boolean deleteProduct(int id) {
        boolean rowDeleted = false;
        try (java.sql.Connection conn = DBConnection.getConnection()) {
            if (conn != null) { 
                PreparedStatement ps = conn.prepareStatement(DELETE_PRODUCT);
                ps.setInt(1, id);
                rowDeleted = ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
}