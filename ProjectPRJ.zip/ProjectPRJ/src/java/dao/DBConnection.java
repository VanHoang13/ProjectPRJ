package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection {
    // Cấu hình kết nối SQL Server
    private static final String DRIVER_NAME = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=Sp25_DemoPRJ1;encrypt=true;trustServerCertificate=true";
    private static final String USER_DB = "sa";
    private static final String PASS_DB = "12345";

    /**
     * Lấy kết nối đến cơ sở dữ liệu SQL Server.
     * @return Connection đối tượng kết nối, hoặc null nếu có lỗi.
     * @throws SQLException nếu không thể kết nối hoặc có lỗi SQL.
     */
    public static Connection getConnection() throws SQLException {
        Connection conn = null;
        try {
            // Đăng ký driver (không cần thiết trong phiên bản mới, nhưng giữ lại cho tương thích)
            Class.forName(DRIVER_NAME);
            // Tạo kết nối với các thông số nâng cao (encrypt và trustServerCertificate cho SQL Server 2016+)
            conn = DriverManager.getConnection(DB_URL, USER_DB, PASS_DB);
            if (conn == null) {
                throw new SQLException("Không thể tạo kết nối đến cơ sở dữ liệu.");
            }
            return conn;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "Không tìm thấy driver SQL Server: " + ex.getMessage(), ex);
            throw new SQLException("Không tìm thấy driver SQL Server: " + ex.getMessage(), ex);
        } catch (SQLException ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "Lỗi khi kết nối đến cơ sở dữ liệu: " + ex.getMessage(), ex);
            throw new SQLException("Lỗi khi kết nối đến cơ sở dữ liệu: " + ex.getMessage(), ex);
        }
    }

    /**
     * Đóng kết nối cơ sở dữ liệu.
     * @param conn đối tượng Connection cần đóng.
     */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, "Lỗi khi đóng kết nối: " + ex.getMessage(), ex);
            }
        }
    }

    // Xóa main() vì không cần thiết trong ứng dụng web
    /*
    public static void main(String[] args) {
        try {
            Connection connection = getConnection();
            if (connection != null) {
                System.out.println("Connect to Sp25_DemoPRJ Success!");
                closeConnection(connection); // Đóng kết nối sau khi test
            }
        } catch (Exception ex) {
            Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    */
}