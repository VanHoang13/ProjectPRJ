/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author ACER
 */

import model.Cart;
import model.Product;

public class CartService implements ICartService { 

    @Override 
    public void addToCart(Cart cart, Product product, int quantity) { 
        cart.addItem(product, quantity); 
    }

    @Override 
    public void updateCartItem(Cart cart, int productId, int quantity) { 
        cart.updateItem(productId, quantity); 
    }

    @Override 
    public void removeCartItem(Cart cart, int productId) { 
        cart.removeItem(productId);  // Sửa lại: Xóa 1 sản phẩm thay vì clear cả giỏ hàng
    }

    @Override 
    public double getTotalPrice(Cart cart) { 
        return cart.calculateTotalPrice();  // Thêm logic tính tổng tiền
    }
}
